'use strict';

// Tile legend
const TILE = {
  GRASS: 0,   // walkable, open ground
  BUSH: 1,    // walkable, hides rabbits from wolves (unless wolf also on a bush)
  WATER: 2,   // unwalkable
  ROCK: 3,    // unwalkable
  CLOVER: 4,  // walkable, food spot (dynamic availability tracked separately)
  beartrap: 5,
  rabbithole: 6, 
};

const TILE_NAME = {
  [TILE.GRASS]: 'grass',
  [TILE.BUSH]: 'bush',
  [TILE.WATER]: 'water',
  [TILE.ROCK]: 'rock',
  [TILE.CLOVER]: 'clover',
  [TILE.beartrap]: "beartrap",
  [TILE.rabbithole]: 'rabbithole'
};

const RAW_MAPS = {
  default: [
    '33333333333333333333333333333333333333333333333',
    '30000000000000002222222200000000000000000022223',
    '30110000000004000222220000400001000000004000223',
    '30110000000000000222200000000011100000000060003',
    '30200000000000002222000000000001000000000000003',
    '32200000000000000220000000000000000000000000003',
    '32000060000000000000000100000020000000000500003',
    '30000000022200000000000000000220000000040000003',
    '30000004000220000000000000402210000000000000003',
    '30040000002200000000110000002210000000000000003',
    '30000111002200000000110000002210000000000000003',
    '30000111202000000400000000002210000000000010003',
    '30000112220000000000000400002210011100000000003',
    '30000000022000000000600000000220011100000000003',
    '30000000000000000000050000000020011100000000003',
    '30000006000000000000001000000000000000000000003',
    '30000000000000000000000000000000000000000000003',
    '30000000000004000000000000000010000000000000003',
    '30000000000000000000000006000000000022200000003',
    '30000000000000000000222000000000000000000000003',
    '30000000600010000000220000000000000100000000003',
    '30000000004000000000000000000000000000000000003',
    '30000000000000000000000000000000000000000540003',
    '30000000000000000004000000020000000000000000003',
    '30000010000000300000000000000000000000000000003',
    '30000000000003302000000000010000000000600000013',
    '31100000000033102200000000000000000000000000113',
    '31111000000333322220000000000000400000000001113',
    '33333333333333333333333333333333333333333333333',
  ],
  small: [
    '333333333333333',
    '300000000000003',
    '301100400110003',
    '301102220110003',
    '300002220000003',
    '300400000040003',
    '333333333333333',
  ],
  arena: [
    '333333333333333333333',
    '300000000000000000003',
    '304000000000000000403',
    '300001111111110000003',
    '300001000000010000003',
    '300001004000010000003',
    '300001000000010000003',
    '300001111111110000003',
    '304000000000000000403',
    '300000000000000000003',
    '333333333333333333333',
  ]
};

function parseMap(rows) {
  return rows.map((row) => row.split('').map((ch) => parseInt(ch, 10)));
}

function getMapData(mapName = 'default') {
  const raw = RAW_MAPS[mapName] || RAW_MAPS.default;
  const grid = parseMap(raw);
  const height = grid.length;
  const width = grid[0].length;

  const inBounds = (x, y) => x >= 0 && x < width && y >= 0 && y < height;
  const tileAt = (x, y) => grid[y][x];
  const isWalkable = (x, y) => inBounds(x, y) && tileAt(x, y) !== TILE.WATER && tileAt(x, y) !== TILE.ROCK;
  const isBush = (x, y) => inBounds(x, y) && tileAt(x, y) === TILE.BUSH;

  const findTilesOfType = (type) => {
    const out = [];
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        if (grid[y][x] === type) out.push({ x, y });
      }
    }
    return out;
  };

  const findSpawnableTiles = () => {
    const out = [];
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        if (isWalkable(x, y) && grid[y][x] !== TILE.CLOVER) out.push({ x, y });
      }
    }
    return out;
  };

  return {
    map: grid,
    width,
    height,
    inBounds,
    tileAt,
    isWalkable,
    isBush,
    findTilesOfType,
    findSpawnableTiles,
  };
}

module.exports = {
  TILE,
  TILE_NAME,
  RAW_MAPS,
  getMapData,
};